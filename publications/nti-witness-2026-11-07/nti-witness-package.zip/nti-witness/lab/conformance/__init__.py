"""Vendored Agent Authority Conformance lab (Apache-2.0)."""
