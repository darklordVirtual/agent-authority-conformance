#!/usr/bin/env python3
"""Rerun this package from a fresh copy: python3 rerun.py"""
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(HERE / "lab"))
from conformance.lab.rerun import main  # noqa: E402

raise SystemExit(main([str(HERE)]))
