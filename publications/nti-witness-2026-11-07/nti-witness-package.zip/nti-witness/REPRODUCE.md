# Reproduce

Recorded with Python 3.13.18. Any Python 3.12 or newer can rerun; a different minor version is reported as a warning.

```sh
python3 rerun.py
```

`rerun.py` verifies MANIFEST.json, fetches each subject at its pinned commit (the only network step, before anything executes), verifies every pinned file hash, recomputes the frozen plan hash, reruns every row or claim with the vendored lab code and compares with results/.

Exit 0 REPRODUCED, 1 DIVERGED (details in reruns/), 2 NOT_REPRODUCIBLE.

A different subject commit is not a rerun: start a follow-up run with `python -m conformance.lab init <new_id> --follow-up <run_id> --commit <sha>`.
