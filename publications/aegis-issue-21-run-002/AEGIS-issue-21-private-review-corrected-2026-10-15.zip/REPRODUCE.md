# Manual reproduction procedure

This is an operator evidence package, not a conformance.lab package. SHA256SUMS verifies byte identity, not authenticity. Verify the plan commitment against the preregistration commit.

Use Python 3.12.14 on a runner matching the documented restrictions, or declare a NEW run identity and preregister any procedural/environment change. Never overwrite this run's output.

1. `sha256sum --check SHA256SUMS`
2. Create fresh temporary cwd and venv outside the producer checkout: `python -m venv /tmp/NEW_RUN/venv`.
3. Install offline with `venv/bin/python -m pip install --no-index --find-links WHEELS_PATH --require-hashes --only-binary=:all: -r LOCK_PATH`.
4. Copy the unchanged fixture into temporary cwd. Verify every frozen plan pin.
5. Capture `/proc/self/status` capability sets, NoNewPrivs, Seccomp and UID mapping. Run 002 required CapEff=CapPrm=CapBnd=0, NoNewPrivs=1, Seccomp=2. No identity-switching was used.
6. Launch origin check and fixture using `subprocess.run([venv_python, '-I', fixture_name], cwd=fresh_directory, env={'PATH':venv_bin+':/usr/bin:/bin','HOME':'/nonexistent','LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'}, capture_output=True, timeout=60)`.
7. Preserve raw stdout/stderr bytes and actual exit status. Confirm aegis version 3.4.0 and import path under fresh venv site-packages. Capture pip freeze.
8. Only after execution, compare the JSON metrics against RUN-PLAN-FROZEN.json expected fields. Setup errors carry null verdict. Retain divergence and output unchanged.
9. Keep delivery private until factual review and separate publication approval. No automatic A-G property credit.
